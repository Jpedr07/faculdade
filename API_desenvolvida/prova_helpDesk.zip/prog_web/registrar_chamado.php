<?php
    session_start();

    // --- debug passado em sala de aula ---
    // echo '<pre>';
    // print_r($_POST);
    // echo '</pre>';

    $arquivo = fopen('arquivo.hd', 'a');
    $id_usuario = session_id();  
    $titulo = str_replace("#", "-", $_POST['titulo']);
    $categoria = str_replace("#", "-", $_POST['categoria']);
    $descricao = str_replace("#", "-", $_POST['descricao']);
    $status = "Solicitação";  

    $texto = $id_usuario . "#" . $titulo . "#" . $categoria . "#" . $descricao . "#" . $status . PHP_EOL;

    fwrite($arquivo, $texto);
    fclose($arquivo);

    header('Location: abrir_chamado.php');
?>
