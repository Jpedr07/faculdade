<?php
    session_start();

    //remover indices do array
    //unset();
    //unset($_SESSION['autenticado]);

    //destruir a variável sessão
    //session_destroy();
    session_destroy();
    header('Location: index.php');

?>