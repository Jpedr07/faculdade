<?php

  require_once "validador_acesso.php";

  $chamados = array();
  //abrir o arquivo .hd
  $arquivo = fopen('arquivo.hd', 'r');

  while(!feof($arquivo)){
    $registro = fgets($arquivo);
    $chamados[] = $registro;
  }

  fclose($arquivo);

  function prioridadeStatus($status) {
  if ($status == "Solicitação") return 1;
  if ($status == "Em andamento") return 2;
  if ($status == "Concluído") return 3;
  return 4;
}

usort($chamados, function($a, $b) {
  $dadosA = explode("#", $a);
  $dadosB = explode("#", $b);
  return prioridadeStatus(trim($dadosA[4])) - prioridadeStatus(trim($dadosB[4]));
});

?>

<html>
  <head>
    <meta charset="utf-8" />
    <title>App Help Desk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
      .card-consultar-chamado {
        padding: 30px 0 0 0;
        width: 100%;
        margin: 0 auto;
      }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-dark bg-dark">
      <a class="navbar-brand" href="#">
        <img src="logo.png" width="30" height="30" alt="">
        App Help Desk
      </a>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="logoff.php">SAIR</a>
        </li>
      </ul>
    </nav>

    <div class="container">    
      <div class="row">
        <div class="card-consultar-chamado">
          <div class="card">
            <div class="card-header">Consulta de chamado</div>
            <div class="card-body">
              <?php foreach($chamados as $chamado) { 
                $chamado_dados = explode("#", $chamado);
              ?>
                <div class="card mb-3 bg-light">
                  <div class="card-body">
                    <h5 class="card-title">Usuário: <?= $chamado_dados[0] ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted">Título: <?= $chamado_dados[1] ?> | Categoria: <?= $chamado_dados[2] ?></h6>
                    <p class="card-text"><?= $chamado_dados[3] ?></p>
                    <p><strong>Status:</strong> <?= $chamado_dados[4] ?></p>
                  </div>
                </div>
              <?php } ?>
              <div class="row mt-5">
                <div class="col-6">
                  <a class="btn btn-lg btn-warning btn-block" href="home.php">Voltar</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>